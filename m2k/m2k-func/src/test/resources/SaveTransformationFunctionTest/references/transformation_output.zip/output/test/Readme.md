Move2Kube
---------
Congratulations! Move2Kube has generated the necessary build artfiacts for moving all your application components to Kubernetes. Using the artifacts in this directory you can deploy your application in a kubernetes cluster.

Next Steps
----------
If container build artifacts are detected/created by Move2Kube, scripts to build them locally are put in "./scripts" directory. For production image build, use the CI/CD pipelines in "./deploy/cicd" directory.

For deployment, use the artifacts in "./deploy" directory.