---
layout: documentation
title: Parodos vs others
---
